package Utils;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class ScreenshotUtils {

    
    public static String captureScreenshot(WebDriver driver, String screenshotName) {
        // Ensure the driver supports taking screenshots
        if (!(driver instanceof TakesScreenshot)) {
            System.err.println("Driver does not support taking screenshots.");
            return null;
        }

        // Cast driver to TakesScreenshot interface
        TakesScreenshot ts = (TakesScreenshot) driver;

        // Get the screenshot as a file
        File sourceFile = ts.getScreenshotAs(OutputType.FILE);

        // Define the target directory for screenshots
        // It's good practice to make this configurable or relative to the project root.
        String screenshotDir = System.getProperty("user.dir") + File.separator + "output" + File.separator + "screenshots";
        File destinationDir = new File(screenshotDir);
        if (!destinationDir.exists()) {
            destinationDir.mkdirs(); // Create the directory if it doesn't exist
        }

        // Generate a unique file name with timestamp
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String destinationPath = screenshotDir + File.separator + screenshotName + "_" + timestamp + ".png";
        File destinationFile = new File(destinationPath);

        try {
            // Copy the screenshot file to the destination
            FileUtils.copyFile(sourceFile, destinationFile);
            System.out.println("Screenshot captured: " + destinationPath);
            return destinationPath;
        } catch (IOException e) {
            System.err.println("Failed to capture screenshot: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}
