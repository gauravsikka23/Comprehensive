package Base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.*;


public class BaseTest {

    
    protected static WebDriver driver;
    protected static String saucedemoUrl; // URL to be initialized at suite level

    
    @BeforeSuite
    @Parameters("url") // This parameter will be read from testng.xml
    public void setupSuite(String url) {
        System.out.println("--- @BeforeSuite: Setting up WebDriver and URL ---");
        saucedemoUrl = url; // Initialize the URL from TestNG.xml parameter
        System.out.println("SauceDemo URL initialized: " + saucedemoUrl);

       
        WebDriverManager.chromedriver().setup();

        // Configure ChromeOptions for headless mode (optional, but good for CI/CD)
        ChromeOptions options = new ChromeOptions();
        // options.addArguments("--headless"); // Uncomment to run in headless mode
        options.addArguments("--window-size=1920,1080"); // Set window size for consistent screenshots
        options.addArguments("--disable-gpu"); // Recommended for headless
        options.addArguments("--no-sandbox"); // Recommended for Docker/CI environments

        driver = new ChromeDriver(options); // Initialize the ChromeDriver
        driver.manage().window().maximize(); // Maximize the browser window
    }

    
    @AfterSuite
    public void tearDownSuite() {
        System.out.println("--- @AfterSuite: Quitting WebDriver ---");
        if (driver != null) {
            driver.quit(); // Close the browser and terminate the WebDriver session
            driver = null; // Set driver to null to indicate it's closed
        }
    }

    
    @BeforeMethod
    public void navigateToBaseURL() {
        System.out.println("--- @BeforeMethod: Navigating to URL: " + saucedemoUrl + " ---");
        driver.get(saucedemoUrl); // Navigate to the base URL
    }

    
    @AfterMethod
    public void afterEachMethod() {
        System.out.println("--- @AfterMethod: Completed a test method ---");
        
    }
}
