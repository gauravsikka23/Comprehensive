package Test;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Base.BaseTest;
import Pages.LoginPage;
import Utils.ScreenshotUtils;


public class LoginTest extends BaseTest {

    private LoginPage loginPage; // Declare LoginPage instance

    @Test(priority = 1, description = "Verify successful login with valid credentials")
    @Parameters({"validUsername", "validPassword"}) // Parameters from testng.xml
    public void testPositiveLogin(String username, String password) {
        System.out.println("\n--- Running Positive Login Test ---");
        System.out.println("Attempting login with Username: " + username + ", Password: " + password);

    
        loginPage = new LoginPage(driver);

     
        loginPage.login(username, password);

       
        String expectedTitle = "Swag Labs";
        String actualTitle = loginPage.getTitle();
        System.out.println("Actual Page Title after login: " + actualTitle);

        try {
            Assert.assertEquals(actualTitle, expectedTitle, "Page title mismatch after successful login!");
            System.out.println("Assertion Passed: Successfully logged in and navigated to the correct page.");
            // Capture screenshot on success
            ScreenshotUtils.captureScreenshot(driver, "PositiveLoginSuccess");
        } catch (AssertionError e) {
            System.err.println("Assertion Failed: " + e.getMessage());
            // Capture screenshot on failure
            ScreenshotUtils.captureScreenshot(driver, "PositiveLoginFailure");
            throw e; // Re-throw the assertion error to mark the test as failed in TestNG report
        }
    }

    
    @Test(priority = 2, description = "Verify unsuccessful login with invalid credentials")
    @Parameters({"invalidUsername", "invalidPassword"}) // Parameters from testng.xml
    public void testNegativeLogin(String invalidUsername, String invalidPassword) {
        System.out.println("\n--- Running Negative Login Test ---");
        System.out.println("Attempting login with Username: " + invalidUsername + ", Password: " + invalidPassword);

        
        loginPage = new LoginPage(driver);


        loginPage.login(invalidUsername, invalidPassword);

     
        String expectedLoginPageTitle = "Swag Labs";
        String actualTitle = loginPage.getTitle();
        System.out.println("Actual Page Title after failed login attempt: " + actualTitle);

        try {
      
            Assert.assertEquals(actualTitle, expectedLoginPageTitle, "Page title changed unexpectedly after failed login!");
            System.out.println("Assertion Passed (Title Check): User remained on the expected page title after failed login.");

          
            String expectedErrorMessage = "Epic sadface: Username and password do not match any user in this service";
            String actualErrorMessage = loginPage.getErrorMessageText();
            System.out.println("Actual Error Message: " + actualErrorMessage);

            Assert.assertTrue(loginPage.isErrorMessageDisplayed(), "Error message was not displayed after failed login.");
            Assert.assertEquals(actualErrorMessage, expectedErrorMessage, "Error message text mismatch!");
            System.out.println("Assertion Passed (Error Message): Correct error message displayed.");

          
            ScreenshotUtils.captureScreenshot(driver, "NegativeLoginSuccess");
        } catch (AssertionError e) {
            System.err.println("Assertion Failed: " + e.getMessage());
       
            ScreenshotUtils.captureScreenshot(driver, "NegativeLoginFailure");
            throw e; 
        }
    }
}
