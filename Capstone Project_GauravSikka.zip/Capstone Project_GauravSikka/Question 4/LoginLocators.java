package com.example.appium.locators;

import org.openqa.selenium.By;


public class LoginLocators {
    // Example locators - adjust based on your actual app's UI elements
    public static final By USERNAME_FIELD = By.cssSelector("android.widget.EditText[content-desc='test-Username']");
    public static final By PASSWORD_FIELD = By.cssSelector("android.widget.EditText[content-desc='test-Password']");
    public static final By LOGIN_BUTTON = By.cssSelector("android.widget.TextView[text='LOGIN']"); // Assuming text-based button
    // Or By.cssSelector("android.widget.Button[content-desc='test-Login Button']") if it's a button with content-desc
    public static final By ERROR_MESSAGE = By.cssSelector("android.view.ViewGroup[data-test='error']"); // Placeholder - actual locator needed
    // Or By.xpath("//android.view.ViewGroup[@content-desc='test-Error message']");
}