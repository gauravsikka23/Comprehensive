package com.example.appium.pages;

import com.example.appium.base.BasePage;
import com.example.appium.locators.ProductsLocators;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.By;

/**
 * Page Object for the SauceDemo Products Screen.
 * Contains methods to interact with products page elements.
 */
public class ProductsPage extends BasePage {

    public ProductsPage(AppiumDriver driver) {
        super(driver);
    }

    /**
     * Gets the text of the "PRODUCTS" title on the page.
     * @return The title text.
     */
    public String getProductsPageTitle() {
        return getElementText(ProductsLocators.PRODUCTS_TITLE);
    }

    /**
     * Clicks the "ADD TO CART" button for a specific item.
     * Note: This is a simplified example. For a real app, you might need
     * to scroll to the item or use a more specific locator.
     * @param itemName The name of the item to add to cart (e.g., "Sauce Labs Backpack").
     */
    public void addItemToCart(String itemName) {
        // This XPath needs to be adjusted based on the app's structure to locate the specific item's add to cart button.
        // For demonstration, we'll use a generic "ADD TO CART" button.
        // A more robust way would be to find the item element first, then find its child add-to-cart button.
        // Example: By.xpath("//*[@text='" + itemName + "']/following-sibling::android.view.ViewGroup//android.widget.TextView[@text='ADD TO CART']")
        clickElement(ProductsLocators.ADD_TO_CART_BUTTON_PREFIX); // Clicks the first "ADD TO CART" found
        System.out.println("Clicked 'Add to Cart' for an item.");
    }

    /**
     * Clicks the shopping cart icon.
     */
    public void clickShoppingCartIcon() {
        clickElement(ProductsLocators.SHOPPING_CART_ICON);
    }

    /**
     * Clicks the burger menu button.
     */
    public void clickMenuButton() {
        clickElement(ProductsLocators.MENU_BUTTON);
    }

    /**
     * Clicks the Logout link in the side menu.
     * Assumes the menu is already open.
     */
    public void clickLogout() {
        clickElement(ProductsLocators.LOGOUT_LINK);
        System.out.println("Clicked Logout from side menu.");
    }

    /**
     * Checks if the Products page title is displayed.
     * @return true if title is displayed, false otherwise.
     */
    public boolean isProductsPageDisplayed() {
        return isElementDisplayed(ProductsLocators.PRODUCTS_TITLE);
    }
}
