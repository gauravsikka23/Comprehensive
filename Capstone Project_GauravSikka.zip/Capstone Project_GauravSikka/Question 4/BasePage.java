package com.example.appium.base;

import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;


public class BasePage {

    protected AppiumDriver driver;
    protected WebDriverWait wait;
    private final Duration DEFAULT_TIMEOUT = Duration.ofSeconds(15); // Default wait timeout


    public BasePage(AppiumDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, DEFAULT_TIMEOUT);
    }

    protected WebElement waitForVisibility(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

 
    protected WebElement waitForClickability(By locator) {
        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

 
    protected void enterText(By locator, String text) {
        WebElement element = waitForVisibility(locator);
        element.clear(); // Clear any existing text
        element.sendKeys(text);
        System.out.println("Entered text '" + text + "' into element located by: " + locator);
    }


    protected void clickElement(By locator) {
        WebElement element = waitForClickability(locator);
        element.click();
        System.out.println("Clicked on element located by: " + locator);
    }


    protected String getElementText(By locator) {
        WebElement element = waitForVisibility(locator);
        String text = element.getText();
        System.out.println("Retrieved text '" + text + "' from element located by: " + locator);
        return text;
    }


    protected boolean isElementDisplayed(By locator) {
        try {
            return waitForVisibility(locator).isDisplayed();
        } catch (Exception e) {
            System.out.println("Element not displayed or found: " + locator + " - " + e.getMessage());
            return false;
        }
    }
}
