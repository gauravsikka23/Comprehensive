package com.example.appium.locators;

import org.openqa.selenium.By;

public class ProductsLocators {
    // Example locators - adjust based on your actual app's UI elements
    public static final By PRODUCTS_TITLE = By.cssSelector("android.widget.TextView[text='PRODUCTS']"); // Or using accessibility id
    public static final By ADD_TO_CART_BUTTON_PREFIX = By.xpath("//android.widget.TextView[@content-desc='ADD TO CART']"); // Generic Add to cart
    // For specific item, you'd need a more complex XPath or find by item name first.
    // Example: By.xpath("//android.widget.TextView[@content-desc='Sauce Labs Backpack']/ancestor::android.view.ViewGroup[1]//android.widget.TextView[@content-desc='ADD TO CART']")

    public static final By SHOPPING_CART_ICON = By.cssSelector("android.view.ViewGroup[content-desc='test-Cart']");
    public static final By MENU_BUTTON = By.cssSelector("android.view.ViewGroup[@content-desc='test-Menu']"); // Burger menu button
    public static final By LOGOUT_LINK = By.cssSelector("android.widget.TextView[text='Logout']"); // Assuming Logout link in sidebar
}
