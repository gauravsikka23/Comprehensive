package com.example.appium.pages;

import com.example.appium.base.BasePage;
import com.example.appium.locators.LoginLocators;
import io.appium.java_client.AppiumDriver;


public class LoginPage extends BasePage {

    public LoginPage(AppiumDriver driver) {
        super(driver);
    }

    /**
     * Enters the username into the username field.
     * @param username The username to enter.
     */
    public void enterUsername(String username) {
        enterText(LoginLocators.USERNAME_FIELD, username);
    }

    /**
     * Enters the password into the password field.
     * @param password The password to enter.
     */
    public void enterPassword(String password) {
        enterText(LoginLocators.PASSWORD_FIELD, password);
    }

    /**
     * Clicks the login button.
     */
    public void clickLoginButton() {
        clickElement(LoginLocators.LOGIN_BUTTON);
    }

    /**
     * Performs the full login operation.
     * @param username The username.
     * @param password The password.
     */
    public void login(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLoginButton();
        System.out.println("Attempted login with username: " + username);
    }

    /**
     * Gets the text of the error message displayed on the login page.
     * @return The error message text.
     */
    public String getErrorMessage() {
        return getElementText(LoginLocators.ERROR_MESSAGE);
    }

    /**
     * Checks if the error message is displayed.
     * @return true if error message is displayed, false otherwise.
     */
    public boolean isErrorMessageDisplayed() {
        return isElementDisplayed(LoginLocators.ERROR_MESSAGE);
    }
}
