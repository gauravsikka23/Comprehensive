package StepDefinations;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

public class FindFlightsSteps {
    WebDriver driver;
    @Given("I am on the home page of the application")
    public void i_am_on_the_home_page_of_the_application() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        driver.get("https://www.makemytrip.com/");
        driver.findElement(By.cssSelector("span[data-cy='closeModal']")).click();
    }
    @When("I select FromCity as {string}")
    public void i_select_from_city_as(String fromCity) {
        driver.findElement(By.id("fromCity")).click();
        driver.findElement(By.cssSelector("input[placeholder='From']")).sendKeys(fromCity);
        driver.findElement(By.cssSelector("p[class*='searchedResult']")).click();
    }
    @When("I select ToCity as {string}")
    public void i_select_to_city_as(String toCity) throws InterruptedException {
        driver.findElement(By.id("toCity")).click();
        driver.findElement(By.cssSelector("input[placeholder='To']")).sendKeys(toCity);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[text()='MAA']")).click();
    }
    @When("I select  a FromDate and ToDate")
    public void i_select_a_from_date_and_to_date() {
        //Select from date
        driver.findElement(By.cssSelector("div[class*='DayPicker-Day'][aria-disabled='false']")).click();

        //Select return date
        driver.findElement(By.cssSelector("p[data-cy='returnDefaultText']")).click();
        driver.findElement(By.cssSelector("div[class*='DayPicker-Day'][aria-disabled='false'][aria-selected='false']")).click();
    }
    @When("I click on the search button")
    public void i_click_on_the_search_button() {
        driver.findElement(By.linkText("SEARCH")).click();
    }
    @Then("I verify valid search result is displayed")
    public void i_verify_valid_search_result_is_displayed() {
        driver.findElement(By.xpath("//button[text()='OKAY, GOT IT!']")).click();

        String searchResultText = driver.findElement(By.cssSelector("div[class='listingRhs']>p>span")).getText();
        String expectedText     = "Flights from Hyderabad to Chennai, and back";
        Assert.assertEquals(expectedText, searchResultText);
    }
    @Then("I close the application")
    public void i_close_the_application() {
        driver.close();
    }
}
