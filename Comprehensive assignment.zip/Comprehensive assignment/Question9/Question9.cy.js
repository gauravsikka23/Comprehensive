describe('Test Suite 1', () => {
  let data;
  let mainTitle1;
  let speakingPageTitle1;
  let keyNoteText1;
  before(function() {
       //access fixture data
       cy.fixture('example').then(function(data1){
         this.data=data1;
        // cy.log(data1.mainTitle);
          mainTitle1 = data1.mainTitle;
          speakingPageTitle1 = data1.speakingPageTitle;
          keyNoteText1 = data1.keyNoteText;
      })
  })

  after(() => {
    // Code to run after all test cases
    cy.log('All tests completed');
  })

  it('Verify Title', function () {
    cy.visit('https://automationpanda.com/2021/12/29/want-to-practice-test-automation-try-these-demo-sites/')
    cy.title().should('eq', mainTitle1);
  })

  it('Verify title of Speaking Page',function () {
    cy.visit('https://automationpanda.com/2021/12/29/want-to-practice-test-automation-try-these-demo-sites/')
    cy.get('a[href*="speaking"]').click();
    cy.title().should('eq', speakingPageTitle1);
  })

  it('should find the element on the page', function () {
    cy.visit('https://automationpanda.com/2021/12/29/want-to-practice-test-automation-try-these-demo-sites/')
    cy.get('a[href*="speaking"]').click();
    // Check if the element exists
    cy.get('#post-10589 > div > h2:nth-child(2)').should('exist');
    //Check the text
    cy.get('#post-10589 > div > h2:nth-child(2)').should('have.text', keyNoteText1);
  })
})